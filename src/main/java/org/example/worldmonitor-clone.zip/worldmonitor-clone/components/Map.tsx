"use client";

import { useEffect, useRef, useState } from "react";
import type { Variant } from "@/app/page";

// ── Static layer data imports ───────────────────────────────────────────────
import { MILITARY_BASES } from "@/lib/layers/military-bases";
import { NUCLEAR_FACILITIES } from "@/lib/layers/nuclear-facilities";
import { DATACENTERS } from "@/lib/layers/datacenters";
import { SUBMARINE_CABLES } from "@/lib/layers/submarine-cables";
import { PORTS } from "@/lib/layers/ports";
import { PIPELINES } from "@/lib/layers/pipelines";
import { WATERWAYS } from "@/lib/layers/waterways";
import { SPACEPORTS } from "@/lib/layers/spaceports";
import { AI_DATA_CENTERS } from "@/lib/layers/ai-datacenters";
import { FINANCIAL_SITES } from "@/lib/layers/financial-sites";
import { TECH_SITES } from "@/lib/layers/tech-sites";
import { MINERAL_SITES } from "@/lib/layers/mineral-sites";
import { GAMMA_IRRADIATORS } from "@/lib/layers/irradiators";
import { resolveTradeRouteSegments } from "@/lib/layers/trade-routes";

type Layer = {
  id: string;
  label: string;
  color: string;
  icon: string;
};

const VARIANT_LAYERS: Record<Variant, Layer[]> = {
  world: [
    { id: "military", label: "Military Bases", color: "#a855f7", icon: "🪖" },
    { id: "nuclear", label: "Nuclear Facilities", color: "#facc15", icon: "☢️" },
    { id: "irradiators", label: "Gamma Irradiators", color: "#f87171", icon: "⚠️" },
    { id: "waterways", label: "Strategic Waterways", color: "#38bdf8", icon: "🌊" },
    { id: "spaceports", label: "Spaceports", color: "#c084fc", icon: "🚀" },
    { id: "tradeRoutes", label: "Trade Routes", color: "#38bdf8", icon: "🚢" },
  ],
  tech: [
    { id: "datacenters", label: "Data Centers", color: "#3b82f6", icon: "🏢" },
    { id: "ai_dc", label: "AI GPU Clusters", color: "#818cf8", icon: "🤖" },
    { id: "cables", label: "Submarine Cables", color: "#06b6d4", icon: "🔌" },
    { id: "tech_hubs", label: "Startup Hubs", color: "#f59e0b", icon: "💡" },
    { id: "tech_hqs", label: "Tech HQs", color: "#10b981", icon: "🏛️" },
    { id: "cloud", label: "Cloud Regions", color: "#7dd3fc", icon: "☁️" },
  ],
  commodity: [
    { id: "ports", label: "Ports", color: "#22c55e", icon: "⚓" },
    { id: "waterways", label: "Strategic Waterways", color: "#38bdf8", icon: "🌊" },
    { id: "tradeRoutes", label: "Trade Routes", color: "#38bdf8", icon: "🚢" },
    { id: "minerals", label: "Critical Minerals", color: "#f97316", icon: "💎" },
    { id: "pipelines", label: "Pipelines", color: "#94a3b8", icon: "🔧" },
  ],
  energy: [
    { id: "nuclear", label: "Nuclear Facilities", color: "#facc15", icon: "☢️" },
    { id: "pipelines", label: "Pipelines", color: "#94a3b8", icon: "🔧" },
    { id: "waterways", label: "Strategic Waterways", color: "#38bdf8", icon: "🌊" },
    { id: "finance", label: "Financial Centers", color: "#fbbf24", icon: "💰" },
  ],
};

type Props = { variant: Variant };

export default function Map({ variant }: Props) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<unknown>(null);
  const [mode, setMode] = useState<"flat" | "globe">("flat");
  const [activeLayers, setActiveLayers] = useState<Set<string>>(
    new Set(VARIANT_LAYERS[variant].map((l) => l.id))
  );

  const layers = VARIANT_LAYERS[variant];

  useEffect(() => {
    setActiveLayers(new Set(VARIANT_LAYERS[variant].map((l) => l.id)));
  }, [variant]);

  const toggleLayer = (id: string) => {
    setActiveLayers((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  useEffect(() => {
    if (!mapRef.current) return;

    const initMap = async () => {
      const maplibre = await import("maplibre-gl");
      await import("maplibre-gl/dist/maplibre-gl.css");

      if (mapInstanceRef.current) {
        (mapInstanceRef.current as { remove: () => void }).remove();
        mapInstanceRef.current = null;
      }

      const map = new maplibre.Map({
        container: mapRef.current!,
        style: {
          version: 8,
          sources: {
            "carto-dark": {
              type: "raster",
              tiles: [
                "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png",
                "https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png",
              ],
              tileSize: 256,
              attribution: "© CartoDB © OpenStreetMap",
            },
          },
          layers: [{ id: "carto-dark-layer", type: "raster", source: "carto-dark" }],
          projection: { type: mode === "globe" ? "globe" : "mercator" },
        },
        center: [20, 30],
        zoom: 2,
      });

      map.on("load", () => {

        // ─────────────────────────────────────────
        // WORLD TAB
        // ─────────────────────────────────────────
        if (variant === "world") {

          // Military bases
          if (activeLayers.has("military")) {
            MILITARY_BASES.forEach(({ lng, lat, name, country, type }) => {
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${country} · ${type}</span>`,
                "#a855f7", 9, "square");
            });
          }

          // Nuclear facilities
          if (activeLayers.has("nuclear")) {
            NUCLEAR_FACILITIES.forEach(({ lng, lat, name, country, type }) => {
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${country} · ${type}</span>`,
                "#facc15", 9, "circle");
            });
          }

          // Strategic waterways
          if (activeLayers.has("waterways")) {
            WATERWAYS.forEach(({ lng, lat, name, type, dailyShips, oilPct, notes }) => {
              const info = [
                dailyShips ? `~${dailyShips} ships/day` : "",
                oilPct ? `%${oilPct} of world oil` : "",
                notes || "",
              ].filter(Boolean).join("<br/>");
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${type}</span><br/>
                 <span style="color:#7dd3fc;font-size:11px">${info}</span>`,
                "#38bdf8", 12, "diamond");
            });
          }

          // Spaceports
          if (activeLayers.has("spaceports")) {
            SPACEPORTS.forEach(({ lng, lat, name, country, operator, status, launches2024 }) => {
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${country} · ${operator}</span><br/>
                 <span style="color:#c084fc;font-size:11px">${status}${launches2024 ? ` · ${launches2024} launches (2024)` : ""}</span>`,
                "#c084fc", 10, "circle");
            });
          }

          // Gamma Irradiators (IAEA DIIF)
          if (activeLayers.has("irradiators")) {
            GAMMA_IRRADIATORS.forEach(({ lon, lat, city, country }) => {
              addDotMarker(map, maplibre, lon, lat,
                `<strong style="color:white">${city}</strong><br/>
                 <span style="color:#9ca3af">${country} · Gamma Irradiator</span><br/>
                 <span style="color:#f87171;font-size:11px">IAEA DIIF Facility</span>`,
                "#f87171", 7, "square");
            });
          }

          // Trade Routes
          if (activeLayers.has("tradeRoutes")) {
            addTradeRoutes(map, maplibre);
          }
        }

        // ─────────────────────────────────────────
        // TECH TAB
        // ─────────────────────────────────────────
        if (variant === "tech") {

          // General data centers
          if (activeLayers.has("datacenters")) {
            DATACENTERS.forEach(({ lng, lat, name, city, country, operator }) => {
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${city}, ${country} · ${operator}</span>`,
                "#3b82f6", 9, "circle");
            });
          }

          // AI GPU Clusters
          if (activeLayers.has("ai_dc")) {
            AI_DATA_CENTERS.forEach(({ lng, lat, name, owner, country, chipCount, chipType, powerMW, status }) => {
              const powerStr = powerMW ? ` · ${powerMW} MW` : "";
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${country} · ${owner}</span><br/>
                 <span style="color:#818cf8;font-size:11px">${chipCount.toLocaleString()} GPU · ${chipType}${powerStr}</span><br/>
                 <span style="color:${status === "existing" ? "#4ade80" : "#fb923c"};font-size:10px">${status === "existing" ? "✓ Active" : "⏳ Planned"}</span>`,
                status === "existing" ? "#818cf8" : "#f59e0b",
                chipCount > 200000 ? 14 : chipCount > 50000 ? 11 : 8,
                "circle");
            });
          }

          // Submarine cables
          if (activeLayers.has("cables")) {
            SUBMARINE_CABLES.forEach((cable) => {
              const sourceId = `cable-${cable.id}`;
              map.addSource(sourceId, {
                type: "geojson",
                data: {
                  type: "Feature",
                  properties: { name: cable.name },
                  geometry: { type: "LineString", coordinates: cable.coordinates },
                },
              });
              map.addLayer({
                id: `cable-line-${cable.id}`,
                type: "line",
                source: sourceId,
                layout: { "line-join": "round", "line-cap": "round" },
                paint: { "line-color": cable.color, "line-width": 1.5, "line-opacity": 0.75 },
              });
              // Endpoint dots
              [cable.coordinates[0], cable.coordinates[cable.coordinates.length - 1]].forEach(([cLng, cLat]) => {
                addDotMarker(map, maplibre, cLng, cLat,
                  `<strong style="color:white">${cable.name}</strong><br/>
                   <span style="color:#9ca3af">Submarine Cable</span>`,
                  cable.color, 6, "circle");
              });
            });
          }

          // Startup hubs
          if (activeLayers.has("tech_hubs")) {
            TECH_SITES.filter(s => s.type === "startup_hub").forEach(({ lng, lat, name, country, city, notes }) => {
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${city}, ${country}</span><br/>
                 ${notes ? `<span style="color:#fbbf24;font-size:11px">${notes}</span>` : ""}`,
                "#f59e0b", 10, "circle");
            });
          }

          // Tech HQs
          if (activeLayers.has("tech_hqs")) {
            TECH_SITES.filter(s => s.type === "tech_hq").forEach(({ lng, lat, name, country, city, company }) => {
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${city}, ${country}</span><br/>
                 ${company ? `<span style="color:#10b981;font-size:11px">${company}</span>` : ""}`,
                "#10b981", 9, "square");
            });
          }

          // Cloud regions
          if (activeLayers.has("cloud")) {
            TECH_SITES.filter(s => s.type === "cloud_region").forEach(({ lng, lat, name, country, city, company }) => {
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${city}, ${country}</span><br/>
                 ${company ? `<span style="color:#7dd3fc;font-size:11px">${company}</span>` : ""}`,
                "#7dd3fc", 8, "circle");
            });
          }
        }

        // ─────────────────────────────────────────
        // COMMODITY TAB
        // ─────────────────────────────────────────
        if (variant === "commodity") {

          // Ports
          if (activeLayers.has("ports")) {
            PORTS.forEach(({ lng, lat, name, country, volume, rank }) => {
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">#${rank} ${name}</strong><br/>
                 <span style="color:#9ca3af">${country} · ${volume}</span>`,
                "#22c55e", 10, "circle");
            });
          }

          // Strategic waterways
          if (activeLayers.has("waterways")) {
            WATERWAYS.forEach(({ lng, lat, name, type, dailyShips, oilPct, notes }) => {
              const info = [
                dailyShips ? `~${dailyShips} gemi/gün` : "",
                oilPct ? `Dünya petrolünün %${oilPct}` : "",
                notes || "",
              ].filter(Boolean).join("<br/>");
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${type}</span><br/>
                 <span style="color:#7dd3fc;font-size:11px">${info}</span>`,
                "#38bdf8", 12, "diamond");
            });
          }

          // Mineral sites
          if (activeLayers.has("minerals")) {
            MINERAL_SITES.forEach(({ lng, lat, name, country, mineral, type: mType, annualOutput }) => {
              const mineralColors: Record<string, string> = {
                Lithium: "#a78bfa", Cobalt: "#60a5fa", REE: "#f472b6",
                Copper: "#f97316", Nickel: "#34d399", Gold: "#fbbf24",
                Uranium: "#a3e635", "Iron/Nickel": "#94a3b8",
              };
              const color = mineralColors[mineral] ?? "#f97316";
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${country} · ${mineral}</span><br/>
                 <span style="color:${color};font-size:11px">${mType}${annualOutput ? ` · ${annualOutput}` : ""}</span>`,
                color, 9, "diamond");
            });
          }

          // Trade Routes
          if (activeLayers.has("tradeRoutes")) {
            addTradeRoutes(map, maplibre, 'c');
          }

          // Pipelines (also shown in commodity)
          if (activeLayers.has("pipelines")) {
            PIPELINES.forEach((pipe) => {
              const sourceId = `cpipe-${pipe.id}`;
              map.addSource(sourceId, {
                type: "geojson",
                data: {
                  type: "Feature",
                  properties: { name: pipe.name },
                  geometry: { type: "LineString", coordinates: pipe.coordinates },
                },
              });
              const pipeColor = (pipe as any).status === 'offline' ? '#ef4444'
                : (pipe as any).status === 'reduced' ? '#f97316'
                  : (pipe as any).color ?? '#94a3b8';
              map.addLayer({
                id: `cpipe-line-${pipe.id}`,
                type: "line",
                source: sourceId,
                layout: { "line-join": "round", "line-cap": "round" },
                paint: { "line-color": pipeColor, "line-width": 2, "line-opacity": 0.85 },
              });
              const mid = pipe.coordinates[Math.floor(pipe.coordinates.length / 2)];
              const cap = (pipe as any).capacityLabel ?? '';
              const status = (pipe as any).status ?? '';
              addDotMarker(map, maplibre, mid[0], mid[1],
                `<strong style="color:white">${pipe.name}</strong><br/>
                 <span style="color:#9ca3af">${(pipe as any).type === "oil" ? "Oil" : "Gas"} · ${(pipe as any).fromCountry} → ${(pipe as any).toCountry}</span><br/>
                 <span style="color:${pipeColor};font-size:11px">${status} · ${cap}</span>`,
                pipeColor, 7, "circle");
            });
          }
        }

        // ─────────────────────────────────────────
        // ENERGY TAB
        // ─────────────────────────────────────────
        if (variant === "energy") {

          // Nuclear facilities
          if (activeLayers.has("nuclear")) {
            NUCLEAR_FACILITIES.forEach(({ lng, lat, name, country, type }) => {
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${country} · ${type}</span>`,
                "#facc15", 10, "circle");
            });
          }

          // Pipelines
          if (activeLayers.has("pipelines")) {
            PIPELINES.forEach((pipe) => {
              const sourceId = `epipe-${pipe.id}`;
              map.addSource(sourceId, {
                type: "geojson",
                data: {
                  type: "Feature",
                  properties: { name: pipe.name },
                  geometry: { type: "LineString", coordinates: pipe.coordinates },
                },
              });
              const pipeColor = (pipe as any).status === 'offline' ? '#ef4444'
                : (pipe as any).status === 'reduced' ? '#f97316'
                  : (pipe as any).color ?? '#94a3b8';
              map.addLayer({
                id: `epipe-line-${pipe.id}`,
                type: "line",
                source: sourceId,
                layout: { "line-join": "round", "line-cap": "round" },
                paint: { "line-color": pipeColor, "line-width": 2, "line-opacity": 0.85 },
              });
              const mid = pipe.coordinates[Math.floor(pipe.coordinates.length / 2)];
              const cap = (pipe as any).capacityLabel ?? '';
              const status = (pipe as any).status ?? '';
              addDotMarker(map, maplibre, mid[0], mid[1],
                `<strong style="color:white">${pipe.name}</strong><br/>
                 <span style="color:#9ca3af">${(pipe as any).type === "oil" ? "Oil" : "Gas"} · ${(pipe as any).fromCountry} → ${(pipe as any).toCountry}</span><br/>
                 <span style="color:${pipeColor};font-size:11px">${status} · ${cap}</span>`,
                pipeColor, 7, "circle");
            });
          }

          // Strategic waterways
          if (activeLayers.has("waterways")) {
            WATERWAYS.forEach(({ lng, lat, name, type, dailyShips, oilPct, notes }) => {
              const info = [
                dailyShips ? `~${dailyShips} ships/day` : "",
                oilPct ? `%${oilPct} of world oil` : "",
                notes || "",
              ].filter(Boolean).join("<br/>");
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${type}</span><br/>
                 <span style="color:#7dd3fc;font-size:11px">${info}</span>`,
                "#38bdf8", 12, "diamond");
            });
          }

          // Financial sites (stock exchanges, central banks, financial centers)
          if (activeLayers.has("finance")) {
            FINANCIAL_SITES.forEach(({ lng, lat, name, city, country, type: fType, marketCap }) => {
              const fColors: Record<string, string> = {
                exchange: "#fbbf24", financial_center: "#f97316", central_bank: "#fb7185",
              };
              const fLabels: Record<string, string> = {
                exchange: "Stock Exchange", financial_center: "Financial Center", central_bank: "Central Bank",
              };
              addDotMarker(map, maplibre, lng, lat,
                `<strong style="color:white">${name}</strong><br/>
                 <span style="color:#9ca3af">${city}, ${country} · ${fLabels[fType] ?? fType}</span><br/>
                 ${marketCap ? `<span style="color:#fbbf24;font-size:11px">Market Cap: ${marketCap}</span>` : ""}`,
                fColors[fType] ?? "#fbbf24", 9, "square");
            });
          }
        }
      });

      mapInstanceRef.current = map;
    };

    initMap();
  }, [mode, variant, activeLayers]);

  useEffect(() => {
    const handleFlyTo = (e: Event) => {
      const customEvent = e as CustomEvent<{ lat: number; lon: number }>;
      const { lat, lon } = customEvent.detail;
      const map = mapInstanceRef.current as any;
      if (map) {
        const targetZoom = (lat === 20 && lon === 30) ? 2 : 5;
        map.flyTo({
          center: [lon, lat],
          zoom: targetZoom,
          speed: 1.5,
          curve: 1.4,
          essential: true
        });
      }
    };

    window.addEventListener("map-fly-to", handleFlyTo);
    return () => {
      window.removeEventListener("map-fly-to", handleFlyTo);
    };
  }, []);

  return (
    <div style={{ width: "100%", height: "100%", position: "relative", background: "#0a0f0a" }}>

      {/* Layers paneli */}
      <div style={{
        position: "absolute",
        top: "12px",
        left: "12px",
        zIndex: 1000,
        background: "rgba(10, 15, 10, 0.92)",
        backdropFilter: "blur(12px)",
        border: "1px solid #1a2e1a",
        borderRadius: "8px",
        padding: "8px 0",
        minWidth: "195px",
        maxHeight: "calc(100vh - 80px)",
        overflowY: "auto",
      }}>
        <div style={{
          padding: "0 10px 6px 10px",
          borderBottom: "1px solid #1a2e1a",
          marginBottom: "4px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}>
          <span style={{
            fontSize: "9px",
            fontWeight: 700,
            color: "#4b6b4b",
            letterSpacing: "0.12em",
            textTransform: "uppercase",
          }}>
            Layers
          </span>
          <span style={{ fontSize: "9px", color: "#4b6b4b" }}>
            {activeLayers.size}/{layers.length}
          </span>
        </div>

        {layers.map((layer) => (
          <button
            key={layer.id}
            onClick={() => toggleLayer(layer.id)}
            onMouseEnter={e => (e.currentTarget.style.background = "#0f1f0f")}
            onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "7px",
              padding: "5px 10px",
              cursor: "pointer",
              width: "100%",
              border: "none",
              background: "transparent",
              textAlign: "left",
            }}
          >
            <span style={{ fontSize: "13px", lineHeight: 1 }}>{layer.icon}</span>
            <span style={{
              fontSize: "12px",
              color: activeLayers.has(layer.id) ? "#c9d1d9" : "#4b5563",
              fontWeight: activeLayers.has(layer.id) ? 500 : 400,
              transition: "color 0.15s",
            }}>
              {layer.label}
            </span>
            {activeLayers.has(layer.id) && (
              <div style={{
                marginLeft: "auto",
                width: "4px",
                height: "4px",
                borderRadius: "50%",
                background: layer.color,
                flexShrink: 0,
              }} />
            )}
          </button>
        ))}
      </div>

      {/* 2D / 3D toggle */}
      <div style={{
        position: "absolute",
        top: "12px",
        right: "12px",
        zIndex: 1000,
        display: "flex",
        background: "rgba(10, 15, 10, 0.92)",
        backdropFilter: "blur(12px)",
        borderRadius: "8px",
        padding: "3px",
        gap: "2px",
        border: "1px solid #1a2e1a",
      }}>
        {(["flat", "globe"] as const).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            style={{
              padding: "5px 14px",
              borderRadius: "6px",
              border: "none",
              cursor: "pointer",
              fontSize: "12px",
              fontWeight: 600,
              background: mode === m ? "#14532d" : "transparent",
              color: mode === m ? "#22c55e" : "#6b7280",
              transition: "all 0.15s",
            }}
          >
            {m === "flat" ? "2D" : "3D"}
          </button>
        ))}
      </div>

      <div ref={mapRef} style={{ width: "100%", height: "100%" }} />
    </div>
  );
}

// ─── Helper ─────────────────────────────────────────────────────────────────
// MapLibre positions markers via CSS transform on the outer element.
// We must NOT apply our own transforms to that same element or markers will
// drift on zoom/pan. Solution: outer div = zero-size neutral anchor (MapLibre
// only touches this); inner div = all visuals + animations.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function addDotMarker(
  map: any,
  maplibre: any,
  lng: number,
  lat: number,
  htmlContent: string,
  color: string,
  size: number,
  shape: "circle" | "square" | "diamond" = "circle"
) {
  // Outer: zero-size, no transforms — MapLibre anchors here
  const outer = document.createElement("div");
  outer.style.cssText = "width:0;height:0;position:relative;";

  // Inner: holds visuals, centered over the anchor point
  const inner = document.createElement("div");
  const half = size / 2;
  const radius = shape === "circle" ? "50%" : shape === "square" ? "2px" : "0";
  const baseTransform = shape === "diamond" ? "translate(-50%,-50%) rotate(45deg)" : "translate(-50%,-50%)";
  inner.style.cssText = `
    position: absolute;
    left: 0; top: 0;
    width: ${size}px; height: ${size}px;
    margin-left: ${-half}px; margin-top: ${-half}px;
    background: ${color};
    border: 1.5px solid rgba(255,255,255,0.55);
    border-radius: ${radius};
    cursor: pointer;
    box-shadow: 0 0 ${size + 2}px ${color}99;
    transition: box-shadow 0.15s, width 0.15s, height 0.15s, margin 0.15s;
  `;

  inner.onmouseenter = () => {
    const s = size * 1.35;
    const h = s / 2;
    inner.style.width = `${s}px`;
    inner.style.height = `${s}px`;
    inner.style.marginLeft = `${-h}px`;
    inner.style.marginTop = `${-h}px`;
    inner.style.boxShadow = `0 0 ${s + 4}px ${color}cc`;
  };
  inner.onmouseleave = () => {
    inner.style.width = `${size}px`;
    inner.style.height = `${size}px`;
    inner.style.marginLeft = `${-half}px`;
    inner.style.marginTop = `${-half}px`;
    inner.style.boxShadow = `0 0 ${size + 2}px ${color}99`;
  };

  outer.appendChild(inner);

  const popup = new maplibre.Popup({ offset: half + 4, closeButton: false })
    .setHTML(`<div style="font-family:-apple-system,sans-serif;font-size:12px;color:#c9d1d9;line-height:1.5">${htmlContent}</div>`);

  new maplibre.Marker({ element: outer, anchor: "center" })
    .setLngLat([lng, lat])
    .setPopup(popup)
    .addTo(map);
}

// ─── Trade Routes Helper ─────────────────────────────────────────────────────
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function addTradeRoutes(map: any, maplibre: any, prefix = 'w') {
  const segments = resolveTradeRouteSegments();
  const categoryLabels: Record<string, string> = {
    container: 'Container',
    energy: 'Energy',
    bulk: 'Bulk Carrier',
  };

  segments.forEach((seg) => {
    const sourceId = `tr-${prefix}-${seg.routeId}`;
    // Avoid duplicate source if already added
    if (map.getSource(sourceId)) return;

    map.addSource(sourceId, {
      type: 'geojson',
      data: {
        type: 'Feature',
        properties: { name: seg.routeName },
        geometry: { type: 'LineString', coordinates: seg.coordinates },
      },
    });
    map.addLayer({
      id: `${sourceId}-line`,
      type: 'line',
      source: sourceId,
      layout: { 'line-join': 'round', 'line-cap': 'round' },
      paint: {
        'line-color': seg.color,
        'line-width': seg.category === 'energy' ? 2.5 : 1.8,
        'line-opacity': 0.7,
        'line-dasharray': seg.category === 'bulk' ? [4, 3] : [1],
      },
    });

    // Midpoint label dot
    const mid = seg.coordinates[Math.floor(seg.coordinates.length / 2)];
    const catLabel = categoryLabels[seg.category] ?? seg.category;
    addDotMarker(map, maplibre, mid[0], mid[1],
      `<strong style="color:white">${seg.routeName}</strong><br/>
       <span style="color:#9ca3af">${catLabel} · ${seg.status}</span><br/>
       <span style="color:${seg.color};font-size:11px">${seg.volumeDesc}</span>`,
      seg.color, 7, 'circle');
  });
}