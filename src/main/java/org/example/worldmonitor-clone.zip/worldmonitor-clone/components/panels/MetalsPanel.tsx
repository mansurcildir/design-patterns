"use client";

import React, { useState, useEffect } from "react";

interface MarketItem {
    ticker: string;
    name: string;
    unit: string;
    category: string;
    price: number;
    change: number;
    history: number[];
}

export default function MetalsPanel() {
    const [marketData, setMarketData] = useState<MarketItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<'commodities' | 'fx'>('commodities');

    const fetchMarketData = async () => {
        try {
            const res = await fetch("/api/market");
            const json = await res.json();
            if (json.success) setMarketData(json.data);
        } catch (err) {
            console.error("Market data fetch error", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchMarketData();
        const interval = setInterval(fetchMarketData, 15000);
        return () => clearInterval(interval);
    }, []);

    if (loading) return <div style={{ padding: "8px 12px", color: "#555", fontSize: "10px", fontFamily: "monospace" }}>SYNCHRONIZING GLOBAL FEEDS...</div>;

    const filteredData = marketData.filter((item) =>
        activeTab === 'commodities' ? item.category === 'metal' : item.category === 'currency'
    );

    return (
        <div style={{ background: "#000000", borderBottom: "1px solid #161616", fontFamily: "monospace" }}>

            {/* --- TAB HEADER --- */}
            <div style={{ display: "flex", background: "#080808", borderBottom: "1px solid #161616", height: "28px" }}>
                <button
                    onClick={() => setActiveTab('commodities')}
                    style={{
                        background: activeTab === 'commodities' ? "#000000" : "transparent",
                        color: activeTab === 'commodities' ? "#00ff00" : "#555",
                        border: "none", borderRight: "1px solid #161616", padding: "0 12px", fontSize: "10px", fontWeight: "bold", cursor: "pointer", outline: "none"
                    }}
                >
                    ⚒️ COMMODITIES ({marketData.filter(i => i.category === 'metal').length})
                </button>

                <button
                    onClick={() => setActiveTab('fx')}
                    style={{
                        background: activeTab === 'fx' ? "#000000" : "transparent",
                        color: activeTab === 'fx' ? "#00d2ff" : "#555",
                        border: "none", borderRight: "1px solid #161616", padding: "0 12px", fontSize: "10px", fontWeight: "bold", cursor: "pointer", outline: "none"
                    }}
                >
                    💱 EUR FX
                </button>
            </div>

            {/* --- CONTENT AREA --- */}
            <div style={{
                maxHeight: "530px",
                overflowY: "auto",
                scrollbarWidth: "none",
                background: "#111111" // Hücre sınır çizgileri için koyu arka plan
            }}>

                {activeTab === 'commodities' ? (

                    /* === COMMODITIES: YAN YANA 3 ANA KOLON (GRAFİKLİ) === */
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "1px" }}>
                        {filteredData.map((item) => {
                            const isUp = item.change >= 0;
                            return (
                                <div key={item.ticker} style={{
                                    background: "#000000",
                                    padding: "0 6px",
                                    height: "38px",
                                    display: "grid",
                                    gridTemplateColumns: "35% 28% 37%",
                                    alignItems: "center",
                                    boxSizing: "border-box"
                                }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = "#070707"}
                                    onMouseLeave={(e) => e.currentTarget.style.background = "#000000"}
                                >
                                    {/* Sol: İsim ve Birim */}
                                    <div style={{ display: "flex", flexDirection: "column", overflow: "hidden" }}>
                                        <span style={{ color: "#aaa", fontSize: "10px", fontWeight: 500, whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden" }}>
                                            {item.name}
                                        </span>
                                        <span style={{ color: "#333", fontSize: "7px", marginTop: "1px" }}>{item.unit}</span>
                                    </div>

                                    {/* Orta: Mini Sparkline */}
                                    <div style={{ height: "10px", width: "100%", padding: "0 1px", display: "flex", alignItems: "center" }}>
                                        <TabSparkline data={item.history} isPositive={isUp} />
                                    </div>

                                    {/* Sağ: Fiyat ve Değişim */}
                                    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", overflow: "hidden" }}>
                                        <span style={{ fontSize: "11px", fontWeight: "bold", color: "#fff", whiteSpace: "nowrap" }}>
                                            {item.price > 100 ? Math.round(item.price).toLocaleString() : item.price.toFixed(2)}
                                        </span>
                                        <span style={{ fontSize: "8px", color: isUp ? "#00ff00" : "#ff3333", marginTop: "1px", whiteSpace: "nowrap" }}>
                                            {isUp ? "▲" : "▼"}{Math.abs(item.change).toFixed(1)}%
                                        </span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                ) : (

                    /* === EUR FX: YAN YANA 3 ANA KOLON (GRAFİKLİ & SİMETRİK) === */
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "1px" }}>
                        {filteredData.map((item) => {
                            const isUp = item.change >= 0;
                            return (
                                <div key={item.ticker} style={{
                                    background: "#000000",
                                    padding: "0 6px",
                                    height: "38px", // Commodities ile birebir aynı yükseklik
                                    display: "grid",
                                    // Tamamen simetrik iç yerleşim oranları
                                    gridTemplateColumns: "35% 28% 37%",
                                    alignItems: "center",
                                    boxSizing: "border-box"
                                }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = "#070707"}
                                    onMouseLeave={(e) => e.currentTarget.style.background = "#000000"}
                                >
                                    {/* Sol: Parite Adı */}
                                    <div style={{ display: "flex", alignItems: "center", overflow: "hidden" }}>
                                        <span style={{ color: "#aaa", fontSize: "10px", fontWeight: 500, whiteSpace: "nowrap", textOverflow: "ellipsis", overflow: "hidden" }}>
                                            {item.name}
                                        </span>
                                    </div>

                                    {/* Orta: FX Mini Sparkline Grafik */}
                                    <div style={{ height: "10px", width: "100%", padding: "0 1px", display: "flex", alignItems: "center" }}>
                                        <TabSparkline data={item.history} isPositive={isUp} />
                                    </div>

                                    {/* Sağ: Fiyat ve Değişim */}
                                    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", overflow: "hidden" }}>
                                        <span style={{ fontSize: "11px", fontWeight: "bold", color: "#ffffff", whiteSpace: "nowrap" }}>
                                            {item.ticker.includes("JPY") ? item.price.toFixed(2) : item.price.toFixed(4)}
                                        </span>
                                        <span style={{ fontSize: "8px", color: isUp ? "#00ff00" : "#ff3333", marginTop: "1px", whiteSpace: "nowrap" }}>
                                            {isUp ? "▲ +" : "▼ "}{Math.abs(item.change).toFixed(2)}%
                                        </span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}

            </div>
        </div>
    );
}

function TabSparkline({ data, isPositive }: { data: number[]; isPositive: boolean }) {
    if (!data || data.length < 2) return null;
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min === 0 ? 1 : max - min;
    const width = 45;
    const height = 10;
    const points = data.map((val, index) => `${(index / (data.length - 1)) * width},${height - ((val - min) / range) * height}`).join(" ");

    return (
        <svg width="100%" height="100%" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" style={{ opacity: 0.85 }}>
            <polyline fill="none" stroke={isPositive ? "#00ff00" : "#ff3333"} strokeWidth="1.2" points={points} />
        </svg>
    );
}