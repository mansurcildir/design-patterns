"use client";

import React from "react";

interface BottomPanelProps {
    onClose?: () => void;
}

export default function BottomPanel({ onClose }: BottomPanelProps) {
    return (
        <div style={{
            width: "100%",
            height: "100%",
            background: "#0d0d0d",
            borderTop: "1px solid #1a1a1a",
            display: "flex",
            flexDirection: "column",
            color: "#e0e0e0",
            boxSizing: "border-box",
        }}>
            {/* Header / Title */}
            <div style={{
                padding: "8px 16px",
                background: "#111",
                borderBottom: "1px solid #222",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                fontSize: "11px",
                letterSpacing: "1px",
                color: "#888",
                height: "28px",
                boxSizing: "border-box",
                userSelect: "none"
            }}>
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    {onClose && (
                        <button
                            onClick={onClose}
                            style={{
                                background: "transparent",
                                border: "1px solid #333",
                                color: "#888",
                                fontSize: "9px",
                                cursor: "pointer",
                                padding: "1px 5px",
                                borderRadius: "3px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontFamily: "monospace",
                                outline: "none",
                                transition: "all 0.15s"
                            }}
                            onMouseEnter={(e) => {
                                e.currentTarget.style.borderColor = "#888";
                                e.currentTarget.style.color = "#fff";
                                e.currentTarget.style.background = "#222";
                            }}
                            onMouseLeave={(e) => {
                                e.currentTarget.style.borderColor = "#333";
                                e.currentTarget.style.color = "#888";
                                e.currentTarget.style.background = "transparent";
                            }}
                        >
                            ▼
                        </button>
                    )}
                    <span>CHANNELS</span>
                </div>
                <span style={{ color: "#22c55e", animation: "pulse 2s infinite" }}>● LIVE</span>
            </div>

            {/* Empty content area with cyber/retro channels aesthetic */}
            <div style={{
                flex: 1,
                background: "#000000",
                padding: "16px",
                overflowY: "auto",
                fontFamily: "monospace",
                fontSize: "11px",
                color: "#22c55e",
                lineHeight: "1.6"
            }}>
                <div style={{ color: "#334155" }}>

                </div>
            </div>
        </div>
    );
}
