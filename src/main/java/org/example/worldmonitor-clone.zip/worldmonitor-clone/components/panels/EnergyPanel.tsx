"use client";

import React, { useState, useEffect } from "react";

interface MarketItem {
    ticker: string;
    name: string;
    unit: string;
    category: string;
    price: number;
    change: number;
}

export default function EnergyPanel() {
    const [energy, setEnergy] = useState<MarketItem[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchEnergyData = async () => {
        try {
            const res = await fetch("/api/market");
            const json = await res.json();
            if (json.success) {
                const filtered = json.data.filter((item: MarketItem) => item.category === "energy");
                setEnergy(filtered);
            }
        } catch (err) {
            console.error("Energy fetch error", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchEnergyData();
        const interval = setInterval(fetchEnergyData, 30000);
        return () => clearInterval(interval);
    }, []);

    if (loading) return <div style={{ padding: "10px", color: "#666", fontSize: "10px", fontFamily: "monospace" }}>LOADING ENERGY COMPLEX...</div>;

    return (
        <div style={{ background: "#000000", fontFamily: "monospace" }}>
            <div style={{
                padding: "6px 12px",
                background: "#0a0a0a",
                borderBottom: "1px solid #161616",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center"
            }}>
                <span style={{ fontSize: "10px", fontWeight: "bold", letterSpacing: "0.5px" }}>
                    ENERGY COMPLEX
                </span>
                <span style={{ color: "#444", fontSize: "9px" }}>EIA TAPE</span>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1px", background: "#111" }}>
                {energy.map((m) => {
                    const isUp = m.change >= 0;
                    return (
                        <div key={m.ticker} style={{
                            background: "#000",
                            padding: "6px 12px",
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "center"
                        }}>
                            <div style={{ fontSize: "9px", color: "#666", textTransform: "uppercase", whiteSpace: "nowrap", overflow: "hidden" }}>
                                {m.name}
                            </div>
                            <div style={{ display: "flex", alignItems: "baseline", gap: "4px", marginTop: "2px" }}>
                                <span style={{ fontSize: "12px", fontWeight: "bold", color: "#fff" }}>{m.price.toFixed(2)}</span>
                                <span style={{ fontSize: "8px", color: "#333" }}>{m.unit}</span>
                            </div>
                            <div style={{ fontSize: "9px", marginTop: "2px", color: isUp ? "#00ff00" : "#ff3333" }}>
                                {isUp ? "▲" : "▼"} {Math.abs(m.change).toFixed(1)}%
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}