"use client";

import React from "react";
import type { Variant } from "@/app/page";

const VARIANTS: { id: Variant; label: string; icon: string }[] = [
  { id: "world", label: "World", icon: "🌍" },
  { id: "tech", label: "Tech", icon: "💻" },
  { id: "commodity", label: "Commodity", icon: "⚡" },
  { id: "energy", label: "Energy", icon: "🛢️" },
];

type Props = {
  variant: Variant;
  onVariantChange: (v: Variant) => void;
};

function Clock() {
  const [time, setTime] = React.useState("");

  React.useEffect(() => {
    const update = () => {
      setTime(new Date().toUTCString().slice(17, 25) + " UTC");
    };
    update();
    const t = setInterval(update, 1000);
    return () => clearInterval(t);
  }, []);

  return <span>{time}</span>;
}

export default function Header({ variant, onVariantChange }: Props) {
  return (
    <header style={{
      height: "44px",
      minHeight: "44px",
      background: "#0a0f0a",
      borderBottom: "1px solid #1a2e1a",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 16px",
      zIndex: 100,
    }}>
      {/* Sol - Logo + Variant tabları */}
      <div style={{ display: "flex", alignItems: "center", gap: "0px" }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: "8px", marginRight: "20px" }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="10" stroke="#22c55e" strokeWidth="1.5" />
            <path d="M2 12h20M12 2a15 15 0 010 20M12 2a15 15 0 000 20" stroke="#22c55e" strokeWidth="1.5" />
          </svg>
          <span style={{
            fontSize: "14px",
            fontWeight: 600,
            color: "#f0fdf4",
            letterSpacing: "0.01em",
          }}>
            World Monitor
          </span>
        </div>

        {/* Variant tabları - logonun hemen yanında */}
        <div style={{
          display: "flex",
          alignItems: "center",
          borderLeft: "1px solid #1a2e1a",
          paddingLeft: "16px",
          gap: "2px",
        }}>
          {VARIANTS.map((v) => (
            <button
              key={v.id}
              onClick={() => onVariantChange(v.id)}
              style={{
                padding: "5px 14px",
                borderRadius: "6px",
                border: "none",
                cursor: "pointer",
                fontSize: "12px",
                fontWeight: variant === v.id ? 600 : 400,
                background: variant === v.id ? "#14532d" : "transparent",
                color: variant === v.id ? "#22c55e" : "#6b7280",
                transition: "all 0.15s",
                letterSpacing: "0.02em",
                display: "flex",
                alignItems: "center",
                gap: "5px",
              }}
            >
              <span style={{ fontSize: "13px" }}>{v.icon}</span>
              {v.label}
            </button>
          ))}
        </div>
      </div>

      {/* Sağ - Saat */}
      <div style={{ fontSize: "12px", color: "#4b5563", fontVariantNumeric: "tabular-nums" }}>
        <Clock />
      </div>
    </header>
  );
}