"use client";

import React from "react";
import MetalsPanel from "./panels/MetalsPanel";
import EnergyPanel from "./panels/EnergyPanel";
import ClimatePanel from "./panels/ClimatePanel";

interface SidebarProps {
    onClose?: () => void;
}

export default function Sidebar({ onClose }: SidebarProps) {
    return (
        <div style={{
            width: "100%",
            height: "100%",
            background: "#0d0d0d",
            borderLeft: "1px solid #1a1a1a",
            display: "flex",
            flexDirection: "column",
            overflowY: "auto",
            color: "#e0e0e0",
            boxSizing: "border-box",
        }}>
            {/* Sidebar Başlığı */}
            <div style={{
                padding: "12px 16px",
                background: "#111",
                borderBottom: "1px solid #222",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                fontSize: "11px",
                letterSpacing: "1px",
                color: "#888"
            }}>
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    {onClose && (
                        <button
                            onClick={onClose}
                            style={{
                                background: "transparent",
                                border: "1px solid #333",
                                color: "#888",
                                fontSize: "9px",
                                cursor: "pointer",
                                padding: "2px 6px",
                                borderRadius: "3px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontFamily: "monospace",
                                outline: "none",
                                transition: "all 0.15s"
                            }}
                            onMouseEnter={(e) => {
                                e.currentTarget.style.borderColor = "#888";
                                e.currentTarget.style.color = "#fff";
                                e.currentTarget.style.background = "#222";
                            }}
                            onMouseLeave={(e) => {
                                e.currentTarget.style.borderColor = "#333";
                                e.currentTarget.style.color = "#888";
                                e.currentTarget.style.background = "transparent";
                            }}
                        >
                            ▶
                        </button>
                    )}
                    <span>PANELS</span>
                </div>
                <span style={{ color: "#00ff00", animation: "pulse 2s infinite" }}>● LIVE</span>
            </div>

            {/* Paneller */}
            <div style={{ display: "flex", flexDirection: "column", gap: "1px", background: "#1a1a1a" }}>
                <MetalsPanel />
                <EnergyPanel />
                <ClimatePanel />
            </div>
        </div>
    );
}