"use client";

import React, { useState, useEffect } from "react";

interface ClimateAnomalyItem {
    stationId: string;
    region: string;
    metric: string;
    currentValue: number;
    anomaly: number;
    lat?: number;
    lon?: number;
}

export default function ClimatePanel() {
    const [climateData, setClimateData] = useState<ClimateAnomalyItem[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchClimateData = async () => {
        try {
            const res = await fetch("/api/climate");
            const json = await res.json();
            if (json.success) setClimateData(json.data);
        } catch (err) {
            console.error("Climate raw fetch error", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchClimateData();
        const interval = setInterval(fetchClimateData, 30000);
        return () => clearInterval(interval);
    }, []);

    if (loading) return <div style={{ padding: "8px 12px", color: "#555", fontSize: "10px", fontFamily: "monospace" }}>CORE::CONNECTING_TO_GLOBAL_ANOMALY_TRACKER...</div>;

    return (
        <div style={{ background: "#000000", fontFamily: "monospace" }}>
            <div style={{
                padding: "6px 12px",
                background: "#0a0a0a",
                borderBottom: "1px solid #161616",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center"
            }}>
                <span style={{ fontSize: "10px", fontWeight: "bold", letterSpacing: "0.5px" }}>
                    CLIMATE SYSTEM MONITOR
                </span>
            </div>

            {/* --- CONTENT AREA (GRAFİKSİZ SAF VERİ AKIŞI) --- */}
            <div style={{ maxHeight: "530px", overflowY: "auto", scrollbarWidth: "none", background: "#000000" }}>
                <div style={{ display: "flex", flexDirection: "column", gap: "1px" }}>
                    {climateData.map((item) => {
                        const isWarm = item.anomaly > 0;
                        const isSevere = Math.abs(item.anomaly) >= 2.0;

                        // World Monitor Klasik Alarm Kodları
                        let statusBadge = <span style={{ color: "#00ff00" }}>[STBL]</span>;
                        let rowBg = "#050505";

                        if (isWarm && isSevere) {
                            statusBadge = <span style={{ color: "#ff3333", fontWeight: "bold", animation: "pulse 1.5s infinite" }}>[CRIT]</span>;
                            rowBg = "#0f0303"; // Kritik satırlara hafif kırmızımsı karartma
                        } else if (isWarm) {
                            statusBadge = <span style={{ color: "#ff6600" }}>[WARN]</span>;
                        } else if (!isWarm && isSevere) {
                            statusBadge = <span style={{ color: "#00d2ff" }}>[COLD]</span>;
                        }

                        return (
                            <div key={item.stationId} style={{
                                background: rowBg,
                                borderBottom: "1px solid #111111",
                                padding: "0 12px",
                                height: "36px", // Grafik kalktığı için Metals ile aynı kompakt dikey hizaya çektik
                                display: "grid",
                                // Jilet gibi 3 ana alan: %15 Durum/ID, %50 Bölge/Metrik, %35 Değerler
                                gridTemplateColumns: "15% 50% 35%",
                                alignItems: "center",
                                boxSizing: "border-box",
                                cursor: "pointer",
                                userSelect: "none"
                            }}
                                onClick={() => {
                                    if (item.lat !== undefined && item.lon !== undefined) {
                                        window.dispatchEvent(
                                            new CustomEvent("map-fly-to", {
                                                detail: { lat: item.lat, lon: item.lon }
                                            })
                                        );
                                    }
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = "#0d0d0d"}
                                onMouseLeave={(e) => e.currentTarget.style.background = rowBg}
                            >
                                {/* Sütun 1: Alarm Kodu ve İstasyon Kısa Adı */}
                                <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                                    <span style={{ fontSize: "10px" }}>{statusBadge}</span>
                                    <span style={{ color: "#444", fontSize: "9px" }}>{item.stationId}</span>
                                </div>

                                {/* Sütun 2: Bölge İsmi ve İzlenen Parametre */}
                                <div style={{ display: "flex", alignItems: "baseline", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                                    <span style={{ color: "#ffffff", fontSize: "11px", fontWeight: "bold" }}>{item.region}</span>
                                    <span style={{ color: "#333", fontSize: "8px", marginLeft: "6px" }}>// CODE_{item.metric}</span>
                                </div>

                                {/* Sütun 3: Saf Canlı Değer ve Sapma Oranı (Sağa Yaslı) */}
                                <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: "16px" }}>
                                    <span style={{ fontSize: "11px", fontWeight: "bold", color: "#fff", minWidth: "45px", textAlign: "right" }}>
                                        {item.currentValue.toFixed(1)}{item.metric.includes("PPM") ? "" : "°C"}
                                    </span>
                                    <span style={{
                                        fontSize: "10px",
                                        color: isWarm ? "#ff3333" : item.anomaly < 0 ? "#00ff00" : "#666",
                                        fontWeight: 500,
                                        minWidth: "55px",
                                        textAlign: "right"
                                    }}>
                                        {item.anomaly > 0 ? `+${item.anomaly}` : item.anomaly} {item.metric.includes("PPM") ? "ppm" : "dev"}
                                    </span>
                                </div>

                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}