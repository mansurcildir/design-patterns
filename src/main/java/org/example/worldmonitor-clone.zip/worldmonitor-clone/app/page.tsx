"use client";

import dynamic from "next/dynamic";
import Header from "@/components/Header";
import { useState, useRef, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import BottomPanel from "@/components/BottomPanel";

const Map = dynamic(() => import("@/components/Map"), { ssr: false });

export type Variant = "world" | "tech" | "commodity" | "energy";

export default function Home() {
  const [variant, setVariant] = useState<Variant>("world");
  const [sidebarWidth, setSidebarWidth] = useState<number>(380); // Varsayılan panel genişliği
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(true);
  const isResizing = useRef<boolean>(false);

  const [bottomHeight, setBottomHeight] = useState<number>(200); // Varsayılan alt panel yüksekliği
  const [isBottomOpen, setIsBottomOpen] = useState<boolean>(true);
  const isBottomResizing = useRef<boolean>(false);

  // Sürükleyerek genişlik ayarlama (Resizable Sidebar)
  const startResizing = (e: React.MouseEvent) => {
    e.preventDefault();
    isResizing.current = true;
  };

  // Sürükleyerek yükseklik ayarlama (Resizable Bottom Panel)
  const startBottomResizing = (e: React.MouseEvent) => {
    e.preventDefault();
    isBottomResizing.current = true;
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isResizing.current) {
        // Ekranın sağından olan mesafeye göre genişliği hesapla
        const newWidth = window.innerWidth - e.clientX;
        if (newWidth > 280 && newWidth < 600) {
          setSidebarWidth(newWidth);
        }
      }

      if (isBottomResizing.current) {
        // Ekranın altından olan mesafeye göre yüksekliği hesapla
        const newHeight = window.innerHeight - e.clientY;
        if (newHeight > 100 && newHeight < 500) {
          setBottomHeight(newHeight);
        }
      }
    };

    const handleMouseUp = () => {
      isResizing.current = false;
      isBottomResizing.current = false;
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, []);

  return (
    <div style={{
      display: "flex",
      flexDirection: "column",
      width: "100vw",
      height: "100vh",
      background: "#0a0a0a",
      overflow: "hidden",
      fontFamily: "monospace",
    }}>
      <Header variant={variant} onVariantChange={setVariant} />

      <div style={{ display: "flex", flex: 1, overflow: "hidden", position: "relative" }}>

        {/* Sol Alan (Harita + Alt Panel) */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", height: "100%", position: "relative" }}>

          {/* Harita Alanı */}
          <div style={{ flex: 1, position: "relative", minHeight: 0 }}>
            <Map variant={variant} />

            {!isSidebarOpen && (
              <button
                onClick={() => setIsSidebarOpen(true)}
                style={{
                  position: "absolute",
                  right: "12px",
                  top: "62px", // Just below the 2D/3D toggle
                  zIndex: 1000,
                  background: "rgba(10, 15, 10, 0.92)",
                  backdropFilter: "blur(12px)",
                  border: "1px solid #1a2e1a",
                  color: "#22c55e",
                  borderRadius: "6px",
                  padding: "6px 12px",
                  fontSize: "11px",
                  fontWeight: "bold",
                  cursor: "pointer",
                  fontFamily: "monospace",
                  letterSpacing: "1px",
                  boxShadow: "0 0 10px rgba(34, 197, 94, 0.2)",
                  transition: "all 0.15s",
                  outline: "none"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "#14532d";
                  e.currentTarget.style.color = "#fff";
                  e.currentTarget.style.borderColor = "#22c55e";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "rgba(10, 15, 10, 0.92)";
                  e.currentTarget.style.color = "#22c55e";
                  e.currentTarget.style.borderColor = "#1a2e1a";
                }}
              >
                ◀ PANELS
              </button>
            )}

            {!isBottomOpen && (
              <button
                onClick={() => setIsBottomOpen(true)}
                style={{
                  position: "absolute",
                  left: "12px",
                  bottom: "12px",
                  zIndex: 1000,
                  background: "rgba(10, 15, 10, 0.92)",
                  backdropFilter: "blur(12px)",
                  border: "1px solid #1a2e1a",
                  color: "#22c55e",
                  borderRadius: "6px",
                  padding: "6px 12px",
                  fontSize: "11px",
                  fontWeight: "bold",
                  cursor: "pointer",
                  fontFamily: "monospace",
                  letterSpacing: "1px",
                  boxShadow: "0 0 10px rgba(34, 197, 94, 0.2)",
                  transition: "all 0.15s",
                  outline: "none"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "#14532d";
                  e.currentTarget.style.color = "#fff";
                  e.currentTarget.style.borderColor = "#22c55e";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "rgba(10, 15, 10, 0.92)";
                  e.currentTarget.style.color = "#22c55e";
                  e.currentTarget.style.borderColor = "#1a2e1a";
                }}
              >
                ▲ CHANNELS
              </button>
            )}
          </div>

          {/* Resize Çubuğu (Alt Panel Sürükleme Alanı) */}
          {isBottomOpen && (
            <div
              onMouseDown={startBottomResizing}
              style={{
                height: "4px",
                cursor: "row-resize",
                background: "#1f1f1f",
                zIndex: 10,
                transition: "background 0.2s",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = "#00ff00")}
              onMouseLeave={(e) => (e.currentTarget.style.background = "#1f1f1f")}
            />
          )}

          {/* Alt Panel / Bottom Bar */}
          {isBottomOpen && (
            <div style={{ height: `${bottomHeight}px`, width: "100%", flexShrink: 0 }}>
              <BottomPanel onClose={() => setIsBottomOpen(false)} />
            </div>
          )}

        </div>

        {/* Resize Çubuğu (Sidebar Sürükleme Alanı) */}
        {isSidebarOpen && (
          <div
            onMouseDown={startResizing}
            style={{
              width: "4px",
              cursor: "col-resize",
              background: "#1f1f1f",
              zIndex: 10,
              transition: "background 0.2s",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.background = "#00ff00")}
            onMouseLeave={(e) => (e.currentTarget.style.background = "#1f1f1f")}
          />
        )}

        {/* Sağ Panel / Sidebar */}
        {isSidebarOpen && (
          <div style={{ width: `${sidebarWidth}px`, height: "100%", flexShrink: 0 }}>
            <Sidebar onClose={() => setIsSidebarOpen(false)} />
          </div>
        )}
      </div>
    </div>
  );
}