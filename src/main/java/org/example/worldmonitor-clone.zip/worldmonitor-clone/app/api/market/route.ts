export const runtime = 'nodejs';

import { NextResponse } from "next/server";

const TICKERS = {
    // METALS
    "GC=F": { name: "Gold", unit: "OZT", category: "metal" },
    "SI=F": { name: "Silver", unit: "OZT", category: "metal" },
    "HG=F": { name: "Copper", unit: "LBS", category: "metal" },
    "PL=F": { name: "Platinum", unit: "OZT", category: "metal" },
    "PA=F": { name: "Palladium", unit: "OZT", category: "metal" },
    "ALI=F": { name: "Aluminum", unit: "MT", category: "metal" },
    "HRC=F": { name: "Steel HRC", unit: "MT", category: "metal" },
    "ZN=F": { name: "Zinc", unit: "MT", category: "metal" },
    "LED=F": { name: "Lead", unit: "MT", category: "metal" },
    "NICK=F": { name: "Nickel", unit: "MT", category: "metal" },
    "UX=F": { name: "Uranium", unit: "LBS", category: "metal" },
    // Yeni Eklenen Stratejik Elementler & Emtialar
    "TIO=F": { name: "Iron Ore 62%", unit: "MT", category: "metal" }, // Demir Cevheri
    "MAL=F": { name: "LME Aluminum", unit: "MT", category: "metal" }, // Londra Metal Borsası Alüminyum
    "LTH=F": { name: "Lithium Hydroxide", unit: "MT", category: "metal" }, // Batarya Lityumu
    "CBL=F": { name: "Cobalt Metal", unit: "LBS", category: "metal" }, // Kobalt
    "MO=F": { name: "Molybdenum", unit: "KGS", category: "metal" }, // Molibden
    "C=F": { name: "Corn Futures", unit: "BU", category: "metal" }, // Tarımsal Gıda Güvencesi - Mısır
    "W=F": { name: "Wheat Futures", unit: "BU", category: "metal" }, // Tarımsal Gıda Güvencesi - Buğday
    "S=F": { name: "Soybeans", unit: "BU", category: "metal" }, // Soya Fasulyesi
    "CT=F": { name: "Cotton", unit: "LBS", category: "metal" },
    // ENERGY
    "CL=F": { name: "Crude Oil WTI", unit: "BBL", category: "energy" },
    "BZ=F": { name: "Brent Crude", unit: "BBL", category: "energy" },
    "NG=F": { name: "Natural Gas", unit: "MMBtu", category: "energy" },
    "RB=F": { name: "RBOB Gasoline", unit: "GAL", category: "energy" },
    "HO=F": { name: "Heating Oil", unit: "GAL", category: "energy" },
    // CURRENCIES (FX TAPE)
    "EURUSD=X": { name: "EUR / USD", unit: "FX", category: "currency" },
    "GBPUSD=X": { name: "GBP / USD", unit: "FX", category: "currency" },
    "USDJPY=X": { name: "USD / JPY", unit: "FX", category: "currency" },
    "AUDUSD=X": { name: "AUD / USD", unit: "FX", category: "currency" },
    "USDCAD=X": { name: "USD / CAD", unit: "FX", category: "currency" },
};

export async function GET() {
    try {
        const results = await Promise.all(
            Object.keys(TICKERS).map(async (ticker) => {
                const config = TICKERS[ticker as keyof typeof TICKERS];
                const url = `https://query1.finance.yahoo.com/v8/finance/chart/${ticker}?range=7d&interval=1d`;

                try {
                    const response = await fetch(url, {
                        headers: {
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                            "Accept": "application/json",
                            "Referer": "https://finance.yahoo.com/"
                        },
                        next: { revalidate: 15 }
                    });

                    if (!response.ok) {
                        console.warn(`[Yahoo API] Ticker ${ticker} failed with status: ${response.status}`);
                        return null;
                    }

                    const json = await response.json();
                    const result = json?.chart?.result?.[0];
                    if (!result) return null;

                    const meta = result?.meta;
                    const history = result?.indicators?.quote?.[0]?.close?.filter((v: any) => v !== null) || [];

                    const price = meta?.regularMarketPrice || (history.length > 0 ? history[history.length - 1] : 0);
                    const previousClose = meta?.chartPreviousClose || (history.length > 1 ? history[history.length - 2] : price);
                    const change = previousClose !== 0 ? ((price - previousClose) / previousClose) * 100 : 0;

                    return {
                        ticker,
                        name: config.name,
                        unit: config.unit,
                        category: config.category,
                        price: price,
                        change: Number(change.toFixed(2)),
                        history: history.length > 0 ? history : [price, price]
                    };
                } catch (err) {
                    console.error(`[Yahoo API] Failed to fetch ticker ${ticker}:`, err);
                    return null;
                }
            })
        );

        const filtered = results.filter((item): item is NonNullable<typeof item> => item !== null);
        return NextResponse.json({ success: true, data: filtered });

    } catch (error) {
        console.error("[Yahoo API Integration Error]:", error);
        return NextResponse.json({ success: false, error: "Yahoo pipeline failed" }, { status: 500 });
    }
}