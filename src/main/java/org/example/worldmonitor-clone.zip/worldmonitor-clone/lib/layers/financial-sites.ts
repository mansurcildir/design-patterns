// Stock exchanges, financial centers, central banks
export type FinancialSite = {
  id: string;
  name: string;
  type: "exchange" | "financial_center" | "central_bank";
  country: string;
  city: string;
  lat: number;
  lng: number;
  marketCap?: string; // e.g. "$25T"
  notes?: string;
};

export const FINANCIAL_SITES: FinancialSite[] = [
  // Stock Exchanges
  { id: "ex1",  name: "NYSE",                          type: "exchange",          country: "USA",         city: "New York",      lat: 40.7069,  lng: -74.0089,  marketCap: "$25T" },
  { id: "ex2",  name: "NASDAQ",                        type: "exchange",          country: "USA",         city: "New York",      lat: 40.7561,  lng: -73.9879,  marketCap: "$22T" },
  { id: "ex3",  name: "Shanghai Stock Exchange",        type: "exchange",          country: "China",       city: "Shanghai",      lat: 31.2200,  lng: 121.5480,  marketCap: "$7.5T" },
  { id: "ex4",  name: "Tokyo Stock Exchange (JPX)",    type: "exchange",          country: "Japan",       city: "Tokyo",         lat: 35.6728,  lng: 139.7707,  marketCap: "$6T" },
  { id: "ex5",  name: "London Stock Exchange",         type: "exchange",          country: "UK",          city: "London",        lat: 51.5142,  lng: -0.0984,   marketCap: "$3.8T" },
  { id: "ex6",  name: "Euronext",                      type: "exchange",          country: "France",      city: "Paris",         lat: 48.8724,  lng: 2.3128,    marketCap: "$5T" },
  { id: "ex7",  name: "Shenzhen Stock Exchange",       type: "exchange",          country: "China",       city: "Shenzhen",      lat: 22.5374,  lng: 114.0478,  marketCap: "$4.5T" },
  { id: "ex8",  name: "Hong Kong Stock Exchange",      type: "exchange",          country: "HK",          city: "Hong Kong",     lat: 22.2793,  lng: 114.1628,  marketCap: "$4.2T" },
  { id: "ex9",  name: "Bombay Stock Exchange",         type: "exchange",          country: "India",       city: "Mumbai",        lat: 18.9348,  lng: 72.8359,   marketCap: "$3.5T" },
  { id: "ex10", name: "Toronto Stock Exchange",        type: "exchange",          country: "Canada",      city: "Toronto",       lat: 43.6488,  lng: -79.3807,  marketCap: "$3.2T" },
  { id: "ex11", name: "Deutsche Börse (Frankfurt)",    type: "exchange",          country: "Germany",     city: "Frankfurt",     lat: 50.1150,  lng: 8.6655,    marketCap: "$2.8T" },
  { id: "ex12", name: "Saudi Exchange (Tadawul)",      type: "exchange",          country: "Saudi Arabia",city: "Riyadh",        lat: 24.7136,  lng: 46.6753,   marketCap: "$2.7T" },
  { id: "ex13", name: "SIX Swiss Exchange",            type: "exchange",          country: "Switzerland", city: "Zurich",        lat: 47.3686,  lng: 8.5392,    marketCap: "$2T" },
  { id: "ex14", name: "ASX (Australian Securities)",   type: "exchange",          country: "Australia",   city: "Sydney",        lat: -33.8687, lng: 151.2069,  marketCap: "$1.7T" },
  { id: "ex15", name: "Korea Exchange (KRX)",          type: "exchange",          country: "South Korea", city: "Seoul",         lat: 37.5567,  lng: 126.9685,  marketCap: "$1.7T" },
  // Financial Centers
  { id: "fc1",  name: "Dubai DIFC",                    type: "financial_center",  country: "UAE",         city: "Dubai",         lat: 25.2096,  lng: 55.2708 },
  { id: "fc2",  name: "Singapore MAS",                 type: "financial_center",  country: "Singapore",   city: "Singapore",     lat: 1.2789,   lng: 103.8536 },
  { id: "fc3",  name: "Zurich Bahnhofstrasse",         type: "financial_center",  country: "Switzerland", city: "Zurich",        lat: 47.3764,  lng: 8.5377 },
  // Central Banks
  { id: "cb1",  name: "Federal Reserve (Fed)",         type: "central_bank",      country: "USA",         city: "Washington DC", lat: 38.8951,  lng: -77.0364 },
  { id: "cb2",  name: "European Central Bank (ECB)",   type: "central_bank",      country: "Germany",     city: "Frankfurt",     lat: 50.1107,  lng: 8.7027 },
  { id: "cb3",  name: "Bank of England",               type: "central_bank",      country: "UK",          city: "London",        lat: 51.5140,  lng: -0.0887 },
  { id: "cb4",  name: "People's Bank of China (PBOC)", type: "central_bank",      country: "China",       city: "Beijing",       lat: 39.9075,  lng: 116.3911 },
  { id: "cb5",  name: "Bank of Japan (BOJ)",           type: "central_bank",      country: "Japan",       city: "Tokyo",         lat: 35.6847,  lng: 139.7750 },
  { id: "cb6",  name: "Swiss National Bank (SNB)",     type: "central_bank",      country: "Switzerland", city: "Bern",          lat: 46.9481,  lng: 7.4494 },
  { id: "cb7",  name: "Reserve Bank of India (RBI)",   type: "central_bank",      country: "India",       city: "Mumbai",        lat: 18.9340,  lng: 72.8370 },
  { id: "cb8",  name: "Saudi Central Bank (SAMA)",     type: "central_bank",      country: "Saudi Arabia",city: "Riyadh",        lat: 24.6828,  lng: 46.6787 },
];
