// Critical minerals mining sites
export type MineralSite = {
  id: string;
  name: string;
  country: string;
  lat: number;
  lng: number;
  mineral: string;
  type: "mine" | "processing" | "reserve";
  annualOutput?: string;
};

export const MINERAL_SITES: MineralSite[] = [
  // Lithium
  { id: "ms1",  name: "Atacama Salt Flat (Lithium)",        country: "Chile",      lat: -23.3000, lng: -68.2500, mineral: "Lithium",  type: "mine",       annualOutput: "160k t" },
  { id: "ms2",  name: "Salar de Uyuni (Lithium)",           country: "Bolivia",    lat: -20.2000, lng: -67.4900, mineral: "Lithium",  type: "reserve",    annualOutput: "World's largest reserve" },
  { id: "ms3",  name: "Pilgangoora (Lithium)",              country: "Australia",  lat: -21.2500, lng: 118.3500, mineral: "Lithium",  type: "mine" },
  { id: "ms4",  name: "Cauchari-Olaroz (Lithium)",          country: "Argentina",  lat: -23.8500, lng: -66.8000, mineral: "Lithium",  type: "mine" },
  // Cobalt
  { id: "ms5",  name: "Tenke Fungurume (Cobalt/Copper)",   country: "DRC",        lat: -10.5900, lng: 26.1300,  mineral: "Cobalt",   type: "mine",       annualOutput: "~30k t/yr" },
  { id: "ms6",  name: "Mutanda Mine",                       country: "DRC",        lat: -10.9200, lng: 25.9500,  mineral: "Cobalt",   type: "mine" },
  // Rare Earth
  { id: "ms7",  name: "Bayan Obo (Rare Earth)",             country: "China",      lat: 41.7700,  lng: 110.1700, mineral: "REE",      type: "mine",       annualOutput: "World's largest" },
  { id: "ms8",  name: "Mountain Pass (REE)",                country: "USA",        lat: 35.4780,  lng: -115.5410, mineral: "REE",     type: "mine" },
  { id: "ms9",  name: "Lynas Mt Weld (REE)",                country: "Australia",  lat: -28.3000, lng: 122.2200, mineral: "REE",      type: "mine" },
  // Copper
  { id: "ms10", name: "Escondida (Copper)",                 country: "Chile",      lat: -24.2700, lng: -69.0700, mineral: "Copper",   type: "mine",       annualOutput: "1.2M t/yr" },
  { id: "ms11", name: "Collahuasi (Copper)",                country: "Chile",      lat: -20.9700, lng: -68.6800, mineral: "Copper",   type: "mine" },
  { id: "ms12", name: "Grasberg (Copper/Gold)",             country: "Indonesia",  lat: -4.0550,  lng: 137.1160, mineral: "Copper",   type: "mine" },
  // Nickel
  { id: "ms13", name: "Sudbury Basin (Nickel)",             country: "Canada",     lat: 46.4900,  lng: -80.9900, mineral: "Nickel",   type: "mine" },
  { id: "ms14", name: "Norilsk (Nickel/Palladium)",         country: "Russia",     lat: 69.3558,  lng: 88.1893,  mineral: "Nickel",   type: "mine",       annualOutput: "~210k t/yr" },
  { id: "ms15", name: "Vale's Carajás (Iron/Nickel)",      country: "Brazil",     lat: -6.0600,  lng: -50.1400, mineral: "Iron/Nickel",type:"mine" },
  // Gold
  { id: "ms16", name: "Muruntau Gold Mine",                 country: "Uzbekistan", lat: 41.5500,  lng: 64.6000,  mineral: "Gold",     type: "mine",       annualOutput: "~66t/yr" },
  { id: "ms17", name: "Boddington Gold Mine",               country: "Australia",  lat: -32.8000, lng: 116.4600, mineral: "Gold",     type: "mine" },
  // Uranium
  { id: "ms18", name: "Cigar Lake (Uranium)",               country: "Canada",     lat: 58.0700,  lng: -104.5300, mineral: "Uranium", type: "mine",       annualOutput: "~7k t/yr" },
  { id: "ms19", name: "Husab Uranium Mine",                 country: "Namibia",    lat: -22.6400, lng: 15.1600,  mineral: "Uranium",  type: "mine" },
  { id: "ms20", name: "Olympic Dam (Uranium/Copper)",       country: "Australia",  lat: -30.4500, lng: 136.8700, mineral: "Uranium",  type: "mine" },
];
