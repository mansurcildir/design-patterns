// Spaceports — launch sites worldwide
export type Spaceport = {
  id: string;
  name: string;
  country: string;
  lat: number;
  lng: number;
  operator: string;
  status: "active" | "planned" | "retired";
  launches2024?: number;
};

export const SPACEPORTS: Spaceport[] = [
  { id: "sp1",  name: "Kennedy Space Center / Cape Canaveral",   country: "USA",       lat: 28.5721, lng: -80.6480, operator: "NASA/SpaceX/ULA",  status: "active", launches2024: 45 },
  { id: "sp2",  name: "Vandenberg Space Force Base",             country: "USA",       lat: 34.7420, lng: -120.5724, operator: "SpaceX/ULA",      status: "active", launches2024: 30 },
  { id: "sp3",  name: "Baikonur Cosmodrome",                     country: "Kazakhstan",lat: 45.9200, lng: 63.3420, operator: "Roscosmos",          status: "active", launches2024: 15 },
  { id: "sp4",  name: "Plesetsk Cosmodrome",                     country: "Russia",    lat: 62.9256, lng: 40.5775, operator: "Roscosmos",          status: "active", launches2024: 10 },
  { id: "sp5",  name: "Jiuquan Satellite Launch Center",         country: "China",     lat: 40.9600, lng: 100.2900, operator: "CASC",             status: "active", launches2024: 22 },
  { id: "sp6",  name: "Xichang Satellite Launch Center",         country: "China",     lat: 28.2467, lng: 102.0267, operator: "CASC",             status: "active", launches2024: 18 },
  { id: "sp7",  name: "Wenchang Space Launch Center",            country: "China",     lat: 19.6147, lng: 110.9510, operator: "CASC",             status: "active", launches2024: 12 },
  { id: "sp8",  name: "Guiana Space Centre (Kourou)",            country: "France",    lat: 5.2360,  lng: -52.7683, operator: "ESA/Arianespace", status: "active", launches2024: 5 },
  { id: "sp9",  name: "Satish Dhawan Space Centre (Sriharikota)",country: "India",     lat: 13.7335, lng: 80.2350, operator: "ISRO",              status: "active", launches2024: 8 },
  { id: "sp10", name: "Tanegashima Space Center",                country: "Japan",     lat: 30.3978, lng: 130.9750, operator: "JAXA",             status: "active", launches2024: 4 },
  { id: "sp11", name: "Naro Space Center",                       country: "South Korea",lat: 34.4327, lng: 127.5350, operator: "KARI",           status: "active", launches2024: 2 },
  { id: "sp12", name: "Starbase (Boca Chica)",                   country: "USA",       lat: 25.9972, lng: -97.1572, operator: "SpaceX",           status: "active", launches2024: 6 },
  { id: "sp13", name: "Mahia Launch Complex",                    country: "New Zealand",lat: -39.2594, lng: 177.8630, operator: "Rocket Lab",    status: "active", launches2024: 10 },
  { id: "sp14", name: "Palmachim Air Base",                      country: "Israel",    lat: 31.8976, lng: 34.6901, operator: "IAI/Rafael",        status: "active" },
  { id: "sp15", name: "Mohammed Bin Rashid Space Centre",        country: "UAE",       lat: 25.1972, lng: 55.2744, operator: "MBRSC",             status: "active" },
  { id: "sp16", name: "Esrange Space Center",                    country: "Sweden",    lat: 67.8900, lng: 21.0800, operator: "SSC",               status: "active" },
  { id: "sp17", name: "SaxaVord Spaceport",                      country: "UK",        lat: 60.8304, lng: -0.7671, operator: "HMG/Lockheed",      status: "planned" },
  { id: "sp18", name: "Alaska Aerospace (Kodiak)",               country: "USA",       lat: 57.4356, lng: -152.3378, operator: "AAC",            status: "active" },
];
