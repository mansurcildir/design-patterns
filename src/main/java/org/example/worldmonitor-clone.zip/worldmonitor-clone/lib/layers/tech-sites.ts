// Tech startup hubs, HQs, cloud regions
export type TechSite = {
  id: string;
  name: string;
  type: "startup_hub" | "tech_hq" | "cloud_region" | "accelerator";
  country: string;
  city: string;
  lat: number;
  lng: number;
  company?: string;
  notes?: string;
};

export const TECH_SITES: TechSite[] = [
  // Startup Hubs
  { id: "th1",  name: "Silicon Valley",          type: "startup_hub",  country: "USA",         city: "San Francisco",   lat: 37.3861, lng: -122.0839, notes: "#1 startup ecosystem globally" },
  { id: "th2",  name: "New York Tech",           type: "startup_hub",  country: "USA",         city: "New York",        lat: 40.7128, lng: -74.0060 },
  { id: "th3",  name: "London Tech City",        type: "startup_hub",  country: "UK",          city: "London",          lat: 51.5274, lng: -0.0878 },
  { id: "th4",  name: "Tel Aviv Startup Nation", type: "startup_hub",  country: "Israel",      city: "Tel Aviv",        lat: 32.0853, lng: 34.7818, notes: "World's highest startup density" },
  { id: "th5",  name: "Singapore Tech Hub",      type: "startup_hub",  country: "Singapore",   city: "Singapore",       lat: 1.3521,  lng: 103.8198 },
  { id: "th6",  name: "Bangalore Tech Corridor", type: "startup_hub",  country: "India",       city: "Bangalore",       lat: 12.9716, lng: 77.5946 },
  { id: "th7",  name: "Beijing Zhongguancun",    type: "startup_hub",  country: "China",       city: "Beijing",         lat: 39.9827, lng: 116.3075 },
  { id: "th8",  name: "Shenzhen Innovation",     type: "startup_hub",  country: "China",       city: "Shenzhen",        lat: 22.5431, lng: 114.0579 },
  { id: "th9",  name: "Berlin Startup Scene",    type: "startup_hub",  country: "Germany",     city: "Berlin",          lat: 52.5200, lng: 13.4050 },
  { id: "th10", name: "Stockholm",               type: "startup_hub",  country: "Sweden",      city: "Stockholm",       lat: 59.3293, lng: 18.0686, notes: "Spotify, Klarna, DICE" },
  { id: "th11", name: "Dubai Innovation Hub",    type: "startup_hub",  country: "UAE",         city: "Dubai",           lat: 25.2048, lng: 55.2708 },
  { id: "th12", name: "São Paulo Tech",          type: "startup_hub",  country: "Brazil",      city: "São Paulo",       lat: -23.5505, lng: -46.6333 },
  // Tech HQs
  { id: "hq1",  name: "Apple Park",              type: "tech_hq",      country: "USA",         city: "Cupertino",       lat: 37.3349, lng: -122.0090, company: "Apple" },
  { id: "hq2",  name: "Googleplex",              type: "tech_hq",      country: "USA",         city: "Mountain View",   lat: 37.4220, lng: -122.0841, company: "Google" },
  { id: "hq3",  name: "Microsoft HQ",            type: "tech_hq",      country: "USA",         city: "Redmond",         lat: 47.6423, lng: -122.1391, company: "Microsoft" },
  { id: "hq4",  name: "Meta HQ",                 type: "tech_hq",      country: "USA",         city: "Menlo Park",      lat: 37.4845, lng: -122.1476, company: "Meta" },
  { id: "hq5",  name: "Amazon HQ2",              type: "tech_hq",      country: "USA",         city: "Arlington VA",    lat: 38.8908, lng: -77.0838, company: "Amazon" },
  { id: "hq6",  name: "NVIDIA HQ",               type: "tech_hq",      country: "USA",         city: "Santa Clara",     lat: 37.3642, lng: -121.9892, company: "NVIDIA" },
  { id: "hq7",  name: "ByteDance HQ",            type: "tech_hq",      country: "China",       city: "Beijing",         lat: 39.9748, lng: 116.3947, company: "ByteDance" },
  { id: "hq8",  name: "Alibaba HQ",              type: "tech_hq",      country: "China",       city: "Hangzhou",        lat: 30.2741, lng: 120.1551, company: "Alibaba" },
  { id: "hq9",  name: "Samsung HQ",              type: "tech_hq",      country: "South Korea", city: "Suwon",           lat: 37.2636, lng: 127.0286, company: "Samsung" },
  { id: "hq10", name: "TSMC HQ",                 type: "tech_hq",      country: "Taiwan",      city: "Hsinchu",         lat: 24.7870, lng: 120.9975, company: "TSMC" },
  // Cloud Regions
  { id: "cr1",  name: "AWS us-east-1 (N.Virginia)",   type: "cloud_region", country: "USA",   city: "Ashburn VA",      lat: 39.0438, lng: -77.4874, company: "AWS" },
  { id: "cr2",  name: "AWS eu-west-1 (Ireland)",      type: "cloud_region", country: "Ireland",city: "Dublin",         lat: 53.3498, lng: -6.2603,  company: "AWS" },
  { id: "cr3",  name: "Azure West Europe",             type: "cloud_region", country: "Netherlands",city: "Amsterdam",  lat: 52.3676, lng: 4.9041,   company: "Azure" },
  { id: "cr4",  name: "GCP europe-west4 (Netherlands)",type: "cloud_region", country: "Netherlands",city: "Eemshaven",  lat: 53.4333, lng: 6.8333,   company: "GCP" },
  { id: "cr5",  name: "AWS ap-northeast-1 (Tokyo)",   type: "cloud_region", country: "Japan", city: "Tokyo",           lat: 35.6762, lng: 139.6503, company: "AWS" },
  { id: "cr6",  name: "AWS ap-southeast-1 (Singapore)",type:"cloud_region", country:"Singapore",city:"Singapore",       lat: 1.3521,  lng: 103.8198, company: "AWS" },
];
