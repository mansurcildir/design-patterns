// AI Data Centers — GPU Clusters
export type AIDataCenter = {
  id: string;
  name: string;
  owner: string;
  country: string;
  lat: number;
  lng: number;
  status: "existing" | "planned";
  chipType: string;
  chipCount: number;
  powerMW?: number;
};

export const AI_DATA_CENTERS: AIDataCenter[] = [
  { id: "dc-1",  name: "OpenAI/Microsoft Mt Pleasant WI Ph2",        owner: "OpenAI,Microsoft",    country: "USA",         lat: 42.6978,  lng: -87.8912,  status: "planned",  chipType: "NVIDIA GB200",          chipCount: 700000 },
  { id: "dc-5",  name: "Meta Prometheus New Albany",                   owner: "Meta AI",             country: "USA",         lat: 40.0812,  lng: -82.8085,  status: "planned",  chipType: "NVIDIA GB200",          chipCount: 500000, powerMW: 1281 },
  { id: "dc-3",  name: "Reliance Industries Supercomputer",            owner: "Reliance Industries", country: "India",       lat: 20.5937,  lng: 79.4629,   status: "planned",  chipType: "NVIDIA GB200",          chipCount: 450000, powerMW: 1000 },
  { id: "dc-22", name: "Project Rainier",                              owner: "Amazon",              country: "USA",         lat: 37.9704,  lng: -97.8378,  status: "planned",  chipType: "Amazon Trainium2",      chipCount: 400000, powerMW: 350 },
  { id: "dc-4",  name: "xAI Colossus 2 Memphis Ph2",                  owner: "xAI",                 country: "USA",         lat: 35.1175,  lng: -89.7439,  status: "planned",  chipType: "NVIDIA GB200",          chipCount: 330000 },
  { id: "dc-6",  name: "OpenAI/Microsoft Atlanta",                     owner: "OpenAI,Microsoft",    country: "USA",         lat: 33.7490,  lng: -84.3880,  status: "planned",  chipType: "NVIDIA B200",           chipCount: 300000 },
  { id: "dc-16", name: "xAI Colossus Memphis Ph3",                    owner: "xAI",                 country: "USA",         lat: 34.8704,  lng: -90.0605,  status: "existing", chipType: "NVIDIA H100 SXM5",      chipCount: 200000 },
  { id: "dc-78", name: "Stargate UAE Phase 1",                        owner: "Stargate (OpenAI)",   country: "UAE",         lat: 24.2968,  lng: 54.5174,   status: "planned",  chipType: "NVIDIA GB300",          chipCount: 100000 },
  { id: "dc-34", name: "G42 Microsoft 100MW UAE Cluster",             owner: "G42,Microsoft",       country: "UAE",         lat: 23.4241,  lng: 54.3478,   status: "planned",  chipType: "NVIDIA H100 SXM5",      chipCount: 55000 },
  { id: "dc-27", name: "xAI Colossus Memphis Ph1",                    owner: "xAI",                 country: "USA",         lat: 35.1221,  lng: -90.1423,  status: "existing", chipType: "NVIDIA H100 SXM5",      chipCount: 100000, powerMW: 150 },
  { id: "dc-83", name: "Microsoft GPT-4 cluster",                     owner: "Microsoft,OpenAI",    country: "USA",         lat: 42.0256,  lng: -93.0338,  status: "existing", chipType: "NVIDIA A100",           chipCount: 25000, powerMW: 21 },
  { id: "dc-85", name: "Oak Ridge NL Frontier",                       owner: "US Dept of Energy",   country: "USA",         lat: 35.9425,  lng: -84.1017,  status: "existing", chipType: "AMD Instinct MI250X",   chipCount: 37632, powerMW: 40 },
  { id: "dc-38", name: "Lawrence Livermore El Capitan",               owner: "US Dept of Energy",   country: "USA",         lat: 37.9127,  lng: -121.9141, status: "existing", chipType: "AMD Instinct MI300A",   chipCount: 44544, powerMW: 35 },
  { id: "dc-2",  name: "Fluidstack France Gigawatt Campus",           owner: "Fluidstack",          country: "France",      lat: 46.2276,  lng: 2.7137,    status: "planned",  chipType: "NVIDIA GB200",          chipCount: 500000, powerMW: 1000 },
  { id: "dc-9",  name: "Sesterce Grand Est France B",                 owner: "Sesterce",            country: "France",      lat: 46.7005,  lng: 1.6976,    status: "planned",  chipType: "NVIDIA GB200",          chipCount: 150000 },
  { id: "dc-33", name: "Nebius Finland Ph2",                          owner: "Nebius AI",           country: "Finland",     lat: 61.9241,  lng: 26.2482,   status: "planned",  chipType: "NVIDIA H100 SXM5",      chipCount: 60000, powerMW: 84 },
  { id: "dc-21", name: "SK Group AWS Ulsan Ph2",                      owner: "SK Telecom,Amazon",   country: "South Korea", lat: 35.9078,  lng: 128.2669,  status: "planned",  chipType: "NVIDIA GB200",          chipCount: 60000, powerMW: 103 },
  { id: "dc-8",  name: "Nebius New Jersey",                           owner: "Nebius AI",           country: "USA",         lat: 40.0583,  lng: -74.4057,  status: "planned",  chipType: "NVIDIA GB200",          chipCount: 150000, powerMW: 300 },
  { id: "dc-305",name: "Neevcloud India Planned",                     owner: "NeevCloud",           country: "India",       lat: 19.7878,  lng: 80.2280,   status: "planned",  chipType: "Unknown",               chipCount: 40000 },
  { id: "dc-313",name: "Large Chinese AI Cluster",                    owner: "PRC Government",      country: "China",       lat: 27.5118,  lng: 111.2018,  status: "existing", chipType: "Unknown",               chipCount: 200000, powerMW: 80 },
  { id: "dc-166",name: "Argonne NL Aurora",                           owner: "US Dept of Energy",   country: "USA",         lat: 41.7003,  lng: -87.9836,  status: "existing", chipType: "Intel Max 1550",        chipCount: 63744, powerMW: 60 },
  { id: "dc-24", name: "Nscale Loughton UK",                         owner: "Nscale",              country: "UK",          lat: 55.3781,  lng: -2.9360,   status: "planned",  chipType: "NVIDIA GB200",          chipCount: 45000, powerMW: 90 },
  { id: "dc-36", name: "Tesla Cortex Ph1",                           owner: "Tesla",               country: "USA",         lat: 30.4364,  lng: -97.6490,  status: "existing", chipType: "NVIDIA H100 SXM5",      chipCount: 50000, powerMW: 71 },
  { id: "dc-47", name: "Jupiter Jülich (EuroHPC)",                   owner: "EuroHPC JU",          country: "Germany",     lat: 50.9067,  lng: 6.3914,    status: "existing", chipType: "NVIDIA H100 SXM5",      chipCount: 24576, powerMW: 15 },
];
