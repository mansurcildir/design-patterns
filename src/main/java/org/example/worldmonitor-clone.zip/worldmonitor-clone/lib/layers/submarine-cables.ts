export type CableLine = {
  id: string;
  name: string;
  color: string;
  coordinates: [number, number][];
};

export const SUBMARINE_CABLES: CableLine[] = [
  {
    id: "sc1",
    name: "SEA-ME-WE 3",
    color: "#06b6d4",
    coordinates: [
      [103.8, 1.3], [79.8, 6.9], [55.3, 25.1], [32.9, 29.9],
      [12.5, 37.9], [4.4, 51.9], [-0.1, 51.5],
    ],
  },
  {
    id: "sc2",
    name: "FLAG / Reliance",
    color: "#8b5cf6",
    coordinates: [
      [-74.0, 40.7], [-9.1, 38.7], [4.4, 51.9], [32.9, 29.9],
      [55.3, 25.1], [72.8, 18.9], [103.8, 1.3], [121.5, 25.0],
    ],
  },
  {
    id: "sc3",
    name: "TAT-14",
    color: "#22c55e",
    coordinates: [
      [-74.0, 40.7], [-40.0, 50.0], [-9.1, 38.7], [4.4, 51.9],
    ],
  },
  {
    id: "sc4",
    name: "Africa Coast to Europe",
    color: "#f97316",
    coordinates: [
      [-0.1, 51.5], [-9.1, 38.7], [-17.1, 14.7], [-15.6, 11.8],
      [-13.7, 9.5], [2.3, 6.4], [9.7, 4.0], [39.2, -6.8],
    ],
  },
  {
    id: "sc5",
    name: "Pacific Light Cable",
    color: "#eab308",
    coordinates: [
      [-118.2, 33.7], [-157.8, 21.3], [114.2, 22.3], [121.5, 25.0],
    ],
  },
  {
    id: "sc6",
    name: "MAREA",
    color: "#ef4444",
    coordinates: [
      [-74.0, 40.7], [-9.1, 38.7], [-8.6, 41.1],
    ],
  },
  {
    id: "sc7",
    name: "2Africa",
    color: "#a855f7",
    coordinates: [
      [-0.1, 51.5], [-9.1, 38.7], [-17.1, 14.7], [-15.0, 10.0],
      [2.3, 6.4], [39.2, -6.8], [57.5, -20.1], [55.4, -4.6],
      [43.1, 11.5], [39.6, 22.9], [32.9, 29.9], [55.3, 25.1],
      [72.8, 18.9], [103.8, 1.3],
    ],
  },
];