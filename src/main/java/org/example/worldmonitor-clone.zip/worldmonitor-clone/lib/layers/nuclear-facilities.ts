export const NUCLEAR_FACILITIES = [
  // ABD
  { id: "nf1", name: "Minuteman III ICBM Fields", country: "ABD", lat: 47.5, lng: -100.5, type: "ICBM" },
  { id: "nf2", name: "Kings Bay Naval Base", country: "ABD", lat: 30.7983, lng: -81.5628, type: "Submarine" },
  { id: "nf3", name: "Nellis Air Force Base", country: "ABD", lat: 36.2361, lng: -115.0344, type: "Air Base" },
  { id: "nf4", name: "Kirtland AFB", country: "ABD", lat: 35.0400, lng: -106.6086, type: "Storage" },
  { id: "nf5", name: "Büchel Air Base", country: "Almanya", lat: 50.1736, lng: 7.0633, type: "NATO Share" },
  { id: "nf6", name: "Kleine Brogel", country: "Belçika", lat: 51.1683, lng: 5.4700, type: "NATO Share" },
  { id: "nf7", name: "Volkel Air Base", country: "Hollanda", lat: 51.6561, lng: 5.7083, type: "NATO Share" },
  // Rusya
  { id: "nf8", name: "Plesetsk Cosmodrome", country: "Rusya", lat: 62.9256, lng: 40.5775, type: "ICBM" },
  { id: "nf9", name: "Severomorsk Naval Base", country: "Rusya", lat: 69.0700, lng: 33.4200, type: "Submarine" },
  { id: "nf10", name: "Gadzhiyevo Naval Base", country: "Rusya", lat: 69.2500, lng: 33.3167, type: "Submarine" },
  { id: "nf11", name: "Dombarovsky ICBM Base", country: "Rusya", lat: 50.7667, lng: 59.5500, type: "ICBM" },
  // Çin
  { id: "nf12", name: "Jilantai Training Area", country: "Çin", lat: 39.7167, lng: 105.8167, type: "ICBM" },
  { id: "nf13", name: "Delingha DF-4 Base", country: "Çin", lat: 37.3667, lng: 97.3667, type: "ICBM" },
  { id: "nf14", name: "Yulin Naval Base", country: "Çin", lat: 18.2333, lng: 109.5333, type: "Submarine" },
  // Hindistan
  { id: "nf15", name: "INS Arihant Base", country: "Hindistan", lat: 17.7000, lng: 83.2833, type: "Submarine" },
  { id: "nf16", name: "Agni Missile Test Range", country: "Hindistan", lat: 20.7500, lng: 86.9167, type: "ICBM" },
  // Pakistan
  { id: "nf17", name: "Sargodha Air Base", country: "Pakistan", lat: 32.0483, lng: 72.6656, type: "Air Base" },
  { id: "nf18", name: "Masroor Air Base", country: "Pakistan", lat: 24.9000, lng: 66.9333, type: "Air Base" },
  // İsrail
  { id: "nf19", name: "Negev Nuclear Research", country: "İsrail", lat: 31.0000, lng: 35.1500, type: "Research" },
  // Kuzey Kore
  { id: "nf20", name: "Yongbyon Nuclear Complex", country: "K.Kore", lat: 39.7939, lng: 125.7544, type: "Reactor" },
  { id: "nf21", name: "Punggye-ri Test Site", country: "K.Kore", lat: 41.2747, lng: 129.0847, type: "Test Site" },
  // Fransa
  { id: "nf22", name: "Ile Longue Submarine Base", country: "Fransa", lat: 48.2833, lng: -4.4167, type: "Submarine" },
  { id: "nf23", name: "Saint-Dizier Air Base", country: "Fransa", lat: 48.6367, lng: 4.8994, type: "Air Base" },
  // UK
  { id: "nf24", name: "HMNB Clyde (Faslane)", country: "İngiltere", lat: 56.0333, lng: -4.8167, type: "Submarine" },
];