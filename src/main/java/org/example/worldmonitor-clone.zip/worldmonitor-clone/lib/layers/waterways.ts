// Strategic waterways / chokepoints
export type Waterway = {
  id: string;
  name: string;
  type: "strait" | "canal" | "passage" | "gulf";
  lat: number;
  lng: number;
  dailyShips?: number;
  oilPct?: number; // % of world oil trade
  notes?: string;
};

export const WATERWAYS: Waterway[] = [
  { id: "ww1",  name: "Strait of Hormuz",       type: "strait",  lat: 26.56, lng: 56.25, dailyShips: 21,  oilPct: 21, notes: "World's most critical oil chokepoint" },
  { id: "ww2",  name: "Strait of Malacca",       type: "strait",  lat: 2.50,  lng: 101.00, dailyShips: 80, oilPct: 15, notes: "Busiest sea lane in the world" },
  { id: "ww3",  name: "Suez Canal",               type: "canal",   lat: 30.50, lng: 32.35, dailyShips: 51, oilPct: 9,  notes: "12% of world trade" },
  { id: "ww4",  name: "Panama Canal",             type: "canal",   lat: 9.08,  lng: -79.68, dailyShips: 40, notes: "Bridge between Atlantic and Pacific" },
  { id: "ww5",  name: "Bab el-Mandeb",            type: "strait",  lat: 12.58, lng: 43.47, dailyShips: 21, oilPct: 6, notes: "Gate of Grief — Red Sea access" },
  { id: "ww6",  name: "Turkish Straits (Bosphorus)", type: "strait", lat: 41.07, lng: 29.04, dailyShips: 48, oilPct: 3, notes: "Connects Black Sea to Mediterranean" },
  { id: "ww7",  name: "Strait of Gibraltar",      type: "strait",  lat: 35.97, lng: -5.47, dailyShips: 80, notes: "Atlantic-Mediterranean gateway" },
  { id: "ww8",  name: "Danish Straits",           type: "passage", lat: 56.00, lng: 10.50, dailyShips: 100, notes: "Baltic Sea access" },
  { id: "ww9",  name: "Lombok Strait",            type: "strait",  lat: -8.75, lng: 115.75, notes: "Alternative to Malacca" },
  { id: "ww10", name: "Mozambique Channel",       type: "passage", lat: -17.00, lng: 41.50, notes: "LNG tanker route" },
  { id: "ww11", name: "Cape of Good Hope",        type: "passage", lat: -34.37, lng: 18.47, notes: "Suez alternative" },
  { id: "ww12", name: "Northwest Passage",        type: "passage", lat: 74.00, lng: -95.00, notes: "Arctic route, opening with climate change" },
];
