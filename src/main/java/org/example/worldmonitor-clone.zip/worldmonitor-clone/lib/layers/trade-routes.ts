// Trade Routes — mirrored from koala73/worldmonitor src/config/trade-routes.ts
// Resolves port + chokepoint IDs to actual coordinates for map rendering

export type TradeRouteCategory = 'container' | 'energy' | 'bulk';
export type TradeRouteStatus = 'active' | 'disrupted' | 'high_risk';

export interface TradeRoute {
  id: string;
  name: string;
  from: string;
  to: string;
  category: TradeRouteCategory;
  status: TradeRouteStatus;
  volumeDesc: string;
  waypoints: string[];
}

export const TRADE_ROUTES: TradeRoute[] = [
  { id: 'china-europe-suez',    name: 'China → Europe (Suez)',           from: 'shanghai',     to: 'rotterdam',   category: 'container', status: 'active',    volumeDesc: '47M+ TEU/year',        waypoints: ['malacca_strait','bab_el_mandeb','suez'] },
  { id: 'china-us-west',        name: 'China → US West Coast',           from: 'shanghai',     to: 'los_angeles', category: 'container', status: 'active',    volumeDesc: '24M+ TEU/year',        waypoints: ['taiwan_strait'] },
  { id: 'china-us-east-suez',   name: 'China → US East Coast (Suez)',    from: 'shenzhen',     to: 'new_york_nj', category: 'container', status: 'active',    volumeDesc: '12M+ TEU/year',        waypoints: ['malacca_strait','bab_el_mandeb','suez'] },
  { id: 'china-us-east-panama', name: 'China → US East Coast (Panama)',  from: 'guangzhou',    to: 'new_york_nj', category: 'container', status: 'active',    volumeDesc: '8M+ TEU/year',         waypoints: ['panama'] },
  { id: 'gulf-europe-oil',      name: 'Persian Gulf → Europe (Oil)',     from: 'ras_tanura',   to: 'rotterdam',   category: 'energy',    status: 'active',    volumeDesc: '6.5M+ bpd',           waypoints: ['hormuz_strait','bab_el_mandeb','suez','gibraltar'] },
  { id: 'gulf-asia-oil',        name: 'Persian Gulf → Asia (Oil)',       from: 'ras_tanura',   to: 'singapore',   category: 'energy',    status: 'active',    volumeDesc: '15M+ bpd',            waypoints: ['hormuz_strait','malacca_strait'] },
  { id: 'qatar-europe-lng',     name: 'Qatar LNG → Europe',              from: 'ras_laffan',   to: 'felixstowe',  category: 'energy',    status: 'active',    volumeDesc: '77M+ tonnes/year',    waypoints: ['hormuz_strait','bab_el_mandeb','suez'] },
  { id: 'qatar-asia-lng',       name: 'Qatar LNG → Asia',                from: 'ras_laffan',   to: 'busan',       category: 'energy',    status: 'active',    volumeDesc: '40M+ tonnes/year',    waypoints: ['hormuz_strait','malacca_strait'] },
  { id: 'us-europe-lng',        name: 'US LNG → Europe',                 from: 'sabine_pass',  to: 'rotterdam',   category: 'energy',    status: 'active',    volumeDesc: '80M+ tonnes/year',    waypoints: [] },
  { id: 'russia-med-oil',       name: 'Russia → Mediterranean (Oil)',    from: 'novorossiysk', to: 'piraeus',     category: 'energy',    status: 'active',    volumeDesc: '140M+ tonnes/year',   waypoints: ['bosphorus'] },
  { id: 'intra-asia-container', name: 'Intra-Asia Container',            from: 'singapore',    to: 'busan',       category: 'container', status: 'active',    volumeDesc: '30M+ TEU/year',       waypoints: ['taiwan_strait'] },
  { id: 'singapore-med',        name: 'Singapore → Mediterranean',       from: 'singapore',    to: 'algeciras',   category: 'container', status: 'active',    volumeDesc: '10M+ TEU/year',       waypoints: ['bab_el_mandeb','suez','gibraltar'] },
  { id: 'brazil-china-bulk',    name: 'Brazil → China (Bulk)',           from: 'santos',       to: 'shanghai',    category: 'bulk',      status: 'active',    volumeDesc: '350M+ tonnes/year',   waypoints: ['cape_of_good_hope'] },
  { id: 'gulf-americas-cape',   name: 'Persian Gulf → Americas (Cape)',  from: 'ras_tanura',   to: 'santos',      category: 'energy',    status: 'active',    volumeDesc: '2M+ bpd',             waypoints: ['hormuz_strait','cape_of_good_hope'] },
  { id: 'asia-europe-cape',     name: 'Asia → Europe (Cape Route)',      from: 'singapore',    to: 'rotterdam',   category: 'container', status: 'active',    volumeDesc: '5M+ TEU/year',        waypoints: ['cape_of_good_hope','gibraltar'] },
  { id: 'india-europe',         name: 'India → Europe',                  from: 'nhava_sheva',  to: 'rotterdam',   category: 'container', status: 'active',    volumeDesc: '6M+ TEU/year',        waypoints: ['bab_el_mandeb','suez','gibraltar'] },
  { id: 'india-se-asia',        name: 'India → SE Asia',                 from: 'mundra',       to: 'singapore',   category: 'container', status: 'active',    volumeDesc: '4M+ TEU/year',        waypoints: ['malacca_strait'] },
  { id: 'china-africa',         name: 'China → Africa',                  from: 'guangzhou',    to: 'djibouti',    category: 'container', status: 'active',    volumeDesc: '5M+ TEU/year',        waypoints: ['malacca_strait'] },
  { id: 'transatlantic',        name: 'TransAtlantic',                   from: 'new_york_nj',  to: 'felixstowe',  category: 'container', status: 'active',    volumeDesc: '8M+ TEU/year',        waypoints: [] },
];

// ── Port coordinates ─────────────────────────────────────────────────────────
// Matches the port IDs referenced in TRADE_ROUTES
const PORT_COORDS: Record<string, [number, number]> = {
  shanghai:     [121.47, 31.23],
  shenzhen:     [114.07, 22.54],
  guangzhou:    [113.27, 23.13],
  rotterdam:    [4.40,   51.90],
  los_angeles:  [-118.25, 33.74],
  new_york_nj:  [-74.01, 40.66],
  singapore:    [103.82,  1.26],
  ras_tanura:   [50.16,  26.65],
  ras_laffan:   [51.55,  25.90],
  sabine_pass:  [-93.87, 29.73],
  novorossiysk: [37.78,  44.72],
  piraeus:      [23.64,  37.94],
  busan:        [129.04, 35.10],
  felixstowe:   [1.33,   51.96],
  santos:       [-46.33, -23.93],
  nhava_sheva:  [72.95,  18.95],
  mundra:       [69.70,  22.84],
  djibouti:     [43.15,  11.59],
  algeciras:    [-5.45,  36.13],
  gwadar:       [62.33,  25.12],
  colon:        [-79.90,  9.36],
  balboa:       [-79.56,  8.96],
};

// ── Chokepoint/waypoint coordinates ──────────────────────────────────────────
// Canonical IDs from chokepoint-registry.ts
const CHOKEPOINT_COORDS: Record<string, [number, number]> = {
  suez:             [32.30,  30.50],
  malacca_strait:   [101.50,  2.50],
  hormuz_strait:    [56.50,  26.50],
  bab_el_mandeb:    [43.30,  12.50],
  panama:           [-79.70,  9.10],
  taiwan_strait:    [119.50, 24.00],
  cape_of_good_hope:[18.49, -34.36],
  gibraltar:        [-5.60,  35.90],
  bosphorus:        [29.00,  41.10],
  korea_strait:     [129.00, 34.00],
};

// ── Category colors ───────────────────────────────────────────────────────────
export const ROUTE_COLORS: Record<TradeRouteCategory, string> = {
  container: '#38bdf8',
  energy:    '#38bdf8',
  bulk:      '#38bdf8',
};

export interface TradeRouteSegment {
  routeId: string;
  routeName: string;
  category: TradeRouteCategory;
  status: TradeRouteStatus;
  volumeDesc: string;
  coordinates: [number, number][];
  color: string;
}

/**
 * Resolves each TRADE_ROUTE into a full coordinate chain
 * (from → waypoints → to) ready for MapLibre LineString rendering.
 */
export function resolveTradeRouteSegments(): TradeRouteSegment[] {
  const segments: TradeRouteSegment[] = [];
  for (const route of TRADE_ROUTES) {
    const from = PORT_COORDS[route.from];
    const to   = PORT_COORDS[route.to];
    if (!from || !to) continue;

    const waypointCoords: [number, number][] = [];
    let valid = true;
    for (const wpId of route.waypoints) {
      const c = CHOKEPOINT_COORDS[wpId];
      if (!c) { valid = false; break; }
      waypointCoords.push(c);
    }
    if (!valid) continue;

    segments.push({
      routeId: route.id,
      routeName: route.name,
      category: route.category,
      status: route.status,
      volumeDesc: route.volumeDesc,
      coordinates: [from, ...waypointCoords, to],
      color: ROUTE_COLORS[route.category],
    });
  }
  return segments;
}
